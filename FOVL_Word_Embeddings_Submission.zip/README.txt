FOVL Word Embeddings - submission package (partial)
Author: Alok Sahni (G25AIT2138)

Included
  FOVL_Word_Embeddings_G25AIT2138.ipynb   Executed notebook with all outputs
  Experimental_Report.pdf                 Final report (IEEE format, 5 pages)
  figures/tsne_<Language>.png             t-SNE plots (x7), taken from the notebook outputs
  tables/language_results.csv             Per-language Spearman, p-value, coverage
  tables/experiments.csv                  E1-E4 ablation results (Hindi, Tamil)
  tables/word_pair_analysis_10.csv        Best/worst rank-agreement word pairs
  tables/results.json                     Macro-average Spearman (0.218957)

The tables are transcribed from the notebook's printed outputs, at printed precision.

Not included (they exist only in the Colab runtime that trained the models)
  embeddings/<Language>.npy               (N, 2, 300) float32 arrays
  vocabulary/<Language>_vocab.json        pair order and word->position index
  models/<Language>_fasttext.model        trained FastText models
  figures/tsne_<Language>_word_labels.csv t-SNE ID -> word mapping
  tables/<Language>_pair_predictions.csv  per-pair cosine predictions
  tables/training_statistics.csv
The complete 49-file package (about 397 MB) is produced by the notebook's final cell at
/content/FOVL_Word_Embeddings_Submission.zip.
